import "./App.css";

function App() {
  return (
    <>
      <h1>hello React</h1>
    </>
  );
}

export default App;
